//모듈 호출
var http = require('http');
var fs = require('fs');
var url = require('url');
var qs = require('querystring');
var template = require('./lib/template.js');
var path = require('path');
var sanitizeHtml = require('sanitize-html');

//서버 생성 함수
var app = http.createServer(function(request,response){

    //URL 정보 다 가져오기
    var _url = request.url;

    //URL에서 쿼리 스트링만 가져오기
    var queryData = url.parse(_url, true).query;

    //URL 경로 가져오기
    var pathname = url.parse(_url, true).pathname;

    //URL에서 쿼리 스트링에서 id만 가져오기
    var title = queryData.id;

    //URL 쿼리 스트링 id값이 undefined일 때
    if (title == undefined){
      title = 'Welcome';
    }

    //경로가 / 일때
    if(pathname === '/'){

      // 파일리스트 추출 함수
      fs.readdir( './data', function(error, filelist) {

        //특정 배열요소 삭제
        var deleteWelcome = filelist.indexOf('Welcome');
        filelist.splice(deleteWelcome,1);

        //파일리스트 추출
        list = template.List(filelist);

        //보안처리
        var filteredID = path.parse(String(queryData.id)).base;

        //본문 내용 가져오는 함수
        fs.readFile(`data/${filteredID}`, 'utf8', function(err, description){

          ////senitizeHTML 처리

          //title
          sanitizedTitle = sanitizeHtml(title);
          //description
          sanitizedDescription = sanitizeHtml(description);

          //Title 값이 Welcome 일때
          if (title === 'Welcome') {
            //템플릿 생성 후 변수 입력(최종)
            var html = template.HTML(title, list, 'Hello World', `
              <a href="/create">Create</a>`);
          }

          // Title 값이 Welcome이 아닐때
          else {
            //템플릿 생성 후 변수 입력(최종)
            var html = template.HTML(sanitizedTitle, list, sanitizedDescription, `
              <a href="/create">Create</a>
              <a href="update?id=${sanitizedTitle}">Update</a>
              <form action="delete_process" method="post">
                <input type="hidden" name="id" value="${sanitizedTitle}">
                <input type="submit" value="Delete">
              </form>
              `);
          }

          //Head에 200 쓰기
          response.writeHead(200);

          //template 변수 리턴
          response.end(html);
        });
      });
    }

    //경로가 create일때
    else if (pathname === '/create') {
      // 파일리스트 추출 함수
      fs.readdir( './data', function(error, filelist) {

        //특정 배열요소 삭제
        var deleteWelcome = filelist.indexOf('Welcome');
        filelist.splice(deleteWelcome,1);

        //파일리스트 추출
        list = template.List(filelist);

        //title
        sanitizedTitle = sanitizeHtml(title);

        //템플릿 생성 후 변수 입력(최종)
        var html = template.HTML(sanitizedTitle, list, `
          <form class="" action="/create_process" method="post">
          <p><input type="text" name="title" value="" placeholder="Title"></p>
          <p><textarea name="description" placeholder="Description" rows="8" cols="80"></textarea></p>
          <p><input type="submit" name="" value="Submit"></p>
          </form>
          `,'');

        //Head에 200 쓰기
        response.writeHead(200);

        //template 변수 리턴
        response.end(html);
      });
    }

    //글 쓰기 기능 구현
    else if (pathname === '/create_process') {

      // body 변수 초기화
      var body = '';

      // post 데이터가 너무 크면 접속 종료
      request.on('data', function (data) {
        body = body + data;

        if (body.length > 1e6) {
          request.connection.destroy();
        }
      });

      // post 데이터 처리
      request.on('end', function () {
        var post = qs.parse(body);

        //title 데이터
        var title = post.title;

        //description 데이터
        var description = post.description;


        //파일 만들기
        fs.writeFile(`data/${title}`, description, 'utf8', function(){

          //Head에 302 쓰고 쓴 글로 이동
          response.writeHead(302, {Location: `/?id=${title}`});

          //결과값 리턴
          response.end();
        });
      });
    }

    //경로가 Update일 때
    else if (pathname === '/update') {

      // 파일리스트 추출 함수
      fs.readdir( './data', function(error, filelist) {

        //특정 배열요소 삭제
        var deleteWelcome = filelist.indexOf('Welcome');
        filelist.splice(deleteWelcome,1);

        //파일리스트 추출
        list = template.List(filelist);

        //보안처리
        var filteredID = path.parse(String(queryData.id)).base;

        ////senitizeHTML 처리

        //title
        sanitizedTitle = sanitizeHtml(title);

        //본문 내용 가져오는 함수
        fs.readFile(`data/${filteredID}`, 'utf8', function(err, description){

        //템플릿 생성 후 변수 입력(최종)
        var html = template.HTML(sanitizedTitle, list,
          `
          <form class="" action="/update_process" method="post">
          <p><input type="hidden" name="id" value="${title}"></p>
          <p><input type="text" name="title" value="${title}" placeholder="Title"></p>
          <p><textarea name="description" placeholder="Description" rows="8" cols="80">${description}</textarea></p>
          <p><input type="submit" name="" value="Submit"></p>
          </form>
          `,
          `
          <a href="/create">Create</a>
          <a href="update?id=${title}">Update</a>
          `);

          //Head에 200 쓰기
          response.writeHead(200);

          //template 변수 리턴
          response.end(html);
          });
      });
    }

    //update 기능 구현
    else if (pathname === '/update_process') {

      // body 변수 초기화
      var body = '';

      // post 데이터가 너무 크면 접속 종료
      request.on('data', function (data) {
        body = body + data;

        if (body.length > 1e6) {
          request.connection.destroy();
        }
      });

      // post 데이터 처리
      request.on('end', function () {
        var post = qs.parse(body);

        //id 데이터
        var id = post.id;

        //title 데이터
        var title = post.title;

        //description 데이터
        var description = post.description;

        ////senitizeHTML 처리

        //title
        sanitizedTitle = sanitizeHtml(title);
        //description
        sanitizedDescription = sanitizeHtml(description);

        fs.rename(`data/${id}`, `data/${title}`, function(error){

          //파일 내용 바꾸기
          fs.writeFile(`data/${title}`, sanitizedDescription, 'utf8', function(){

            //Head에 302 쓰고 쓴 글로 이동
            response.writeHead(302, {Location: `/?id=${title}`});

            //결과값 리턴
            response.end();
          });
        });
      });
    }

    //Delete 기능 구현
    else if (pathname === '/delete_process') {

      // body 변수 초기화
      var body = '';

      // post 데이터가 너무 크면 접속 종료
      request.on('data', function (data) {
        body = body + data;

        if (body.length > 1e6) {
          request.connection.destroy();
        }
      });

      // post 데이터 처리
      request.on('end', function () {
        var post = qs.parse(body);

        //id 데이터
        var id = post.id;

        //보안처리
        var Fileter_PostID  = path.parse(id).base;

        //삭제 기능 함수
        fs.unlink( `data/${Fileter_PostID}`, function(error){

          //Head에 302 쓰고 쓴 글로 이동
          response.writeHead(302, {Location: `/`});

          //결과값 리턴
          response.end();
        });
      });
    }

    //경로가 없을때
    else {

    //Head에 404 쓰기
    response.writeHead(404);

    //Not Found 리턴
    response.end('Not found');
    }
  });

//3000번 포트로 서버 생성
app.listen(3000);
