var args = process.argv[2]

console.log('A');
console.log('B');
if ( args == 1) {
  console.log('C1');
} else {
  console.log('C2');
}
console.log('D');
