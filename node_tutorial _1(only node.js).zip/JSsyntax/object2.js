// array, f1

function f1 () {
  console.log(1+1);
  console.log(1+2);
}
