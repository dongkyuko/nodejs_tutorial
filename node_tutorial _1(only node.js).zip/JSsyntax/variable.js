var a = 1;
console.log(a);
var a = 2;
console.log(a);
